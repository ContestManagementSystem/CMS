/**
 *  Soluzione di prodotto matrici
 *
 *  Autore: Romeo Rizzi
 *
 *  Descrizione: Banale
 */

const int MAX_M = 1000;
const int MAX_N = 1000;
const int MAX_H = 1000;
const int MAX_K = 1000;

int A[MAX_M][MAX_N], B[MAX_H][MAX_K];

#include <iostream>
using namespace std;
int main() {
#ifdef EVAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int M, N, H, K;
    cin >> M >> N >> H >> K;
    for(int i = 0; i<M; i++)
       for(int j = 0; j<N; j++)
          cin >> A[i][j];
    for(int i = 0; i<H; i++)
       for(int j = 0; j<K; j++)
          cin >> B[i][j];
    if(N != H) cout << "0 0" << endl;
    else
      for(int i = 0; i<M; i++) {
	for(int j = 0; j<K; j++) {
           int Cij = 0;
           for(int k = 0; k<N; k++)
	     Cij += A[i][k]*B[k][j];
	   cout << Cij << " ";
         }
	cout << endl;
      }
    return 0;
}

