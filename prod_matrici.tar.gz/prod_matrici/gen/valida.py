#!/usr/bin/env python2

from limiti import *

import sys
import os

def usage():
    print >> sys.stderr, "Usage: %s file_input.txt [subtask_number]" % \
        os.path.basename(sys.argv[0])
    exit(1)


# 0            -> corretto
# altro numero -> non corretto
def run(f, st):
#    print "SUbtask: "
#    print st
    M, N, H, K = map(int, f[0].split())
#    print M, N, H, K
    if M < 1:
        return -1
    if M > MAXN:
        return -1
    if N < 1:
        return -1
    if N > MAXN:
        return -1
    if H < 1:
        return -1
    if H > MAXN:
        return -1
    if K < 1:
        return -1
    if K > MAXN:
        return -1
    if st == 2 and M != 2:
        return -1
    if st == 2 and N != 2:
        return -1
    if st == 2 and H != 2:
        return -1
    if st == 2 and K != 2:
        return -1
    if st == 3 and M != 1:
        return -1
    if st == 3 and K != 1:
        return -1
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()

    # Di default, ignora i subtask
    st = 0

    if len(sys.argv) == 3:
        st = int(sys.argv[2])

    f = open(sys.argv[1]).readlines()
    exit(run(f, st))
