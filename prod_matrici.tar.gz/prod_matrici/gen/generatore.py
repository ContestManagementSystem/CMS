#!/usr/bin/env python2

from limiti import *
from varie import *
from random import randint
from sys import argv, exit, stderr
import os

usage="""Generatore di "prod_matrici".

Parametri:
* M N H K (numero)
* S (seed)

Constraint:
* 1 <= M, N, H, K <= %d
""" % (MAXN)


def run(M, N, H, K):
    print M, N, H, K
    for i in range(0,M):
        for j in range(0,N):
           print(randint(-1,1)),
        print
    for i in range(0,H):
        for j in range(0,K):
           print(randint(-1,1)),
        print

if __name__ == "__main__":
    if len(argv) != 6:
        print usage
        exit(1)

    M, N, H, K, S = map(int, argv[1:])

    # su seed non positivo copia un input di esempio dal .tex
    if S <= 0:
        print extract_input()[-S],
        exit(0)

    assert (1 <= M <= MAXN)
    assert (1 <= N <= MAXN)
    assert (1 <= H <= MAXN)
    assert (1 <= K <= MAXN)

    run(M, N, H, K)

